import { Star, ShoppingCart } from 'lucide-react';
import type { Database } from '../lib/database.types';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';

type Product = Database['public']['Tables']['products']['Row'];

interface ProductCardProps {
  product: Product;
  onClick: () => void;
}

export function ProductCard({ product, onClick }: ProductCardProps) {
  const { addToCart } = useCart();
  const { user } = useAuth();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (user) {
      addToCart(product.id);
    }
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden group"
    >
      <div className="relative aspect-square overflow-hidden bg-slate-100">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {product.featured && (
          <div className="absolute top-3 left-3 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full">
            Featured
          </div>
        )}
        {product.stock <= 5 && product.stock > 0 && (
          <div className="absolute top-3 right-3 bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full">
            Low Stock
          </div>
        )}
        {product.stock === 0 && (
          <div className="absolute top-3 right-3 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-full">
            Out of Stock
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-slate-900 mb-1 line-clamp-1">{product.name}</h3>
        <p className="text-sm text-slate-600 mb-3 line-clamp-2">{product.description}</p>

        <div className="flex items-center gap-1 mb-3">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium text-slate-900">{product.rating.toFixed(1)}</span>
          <span className="text-sm text-slate-500">({Math.floor(Math.random() * 500) + 100})</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-slate-900">${product.price.toFixed(2)}</span>
          {user && product.stock > 0 && (
            <button
              onClick={handleAddToCart}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <ShoppingCart className="w-4 h-4" />
              <span className="text-sm font-medium">Add</span>
            </button>
          )}
          {!user && (
            <span className="text-sm text-slate-500">Sign in to buy</span>
          )}
        </div>
      </div>
    </div>
  );
}
