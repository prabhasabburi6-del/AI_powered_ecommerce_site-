import { useState } from 'react';
import { Header } from './components/Header';
import { ProductList } from './components/ProductList';
import { ProductDetail } from './components/ProductDetail';
import { CartSidebar } from './components/CartSidebar';
import { Checkout } from './components/Checkout';
import { Orders } from './components/Orders';
import { AuthModal } from './components/AuthModal';
import type { Database } from './lib/database.types';

type Product = Database['public']['Tables']['products']['Row'];
type View = 'products' | 'product-detail' | 'checkout' | 'orders' | 'order-success';

function App() {
  const [currentView, setCurrentView] = useState<View>('products');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentView('product-detail');
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setCurrentView('checkout');
  };

  const handleOrderSuccess = () => {
    setCurrentView('order-success');
    setTimeout(() => {
      setCurrentView('products');
    }, 3000);
  };

  const handleBackToProducts = () => {
    setCurrentView('products');
    setSelectedProduct(null);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header
        onCartClick={() => setIsCartOpen(true)}
        onAuthClick={() => setIsAuthModalOpen(true)}
        onOrdersClick={() => setCurrentView('orders')}
        onHomeClick={handleBackToProducts}
        currentView={currentView}
      />

      {currentView === 'products' && <ProductList onProductClick={handleProductClick} />}

      {currentView === 'product-detail' && selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          onBack={handleBackToProducts}
          onProductClick={handleProductClick}
        />
      )}

      {currentView === 'checkout' && (
        <Checkout onBack={() => setCurrentView('products')} onSuccess={handleOrderSuccess} />
      )}

      {currentView === 'orders' && <Orders onBack={handleBackToProducts} />}

      {currentView === 'order-success' && (
        <div className="min-h-screen flex items-center justify-center">
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center max-w-md">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg
                className="w-8 h-8 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Order Placed Successfully</h2>
            <p className="text-slate-600">
              Thank you for your purchase. You will receive a confirmation email shortly.
            </p>
          </div>
        </div>
      )}

      <CartSidebar
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={handleCheckout}
      />

      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </div>
  );
}

export default App;
